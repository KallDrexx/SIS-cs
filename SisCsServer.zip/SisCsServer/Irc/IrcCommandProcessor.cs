﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SisCsServer.Irc
{
    public class IrcCommandProcessor
    {
        private readonly IrcController _controller;

        public IrcCommandProcessor(IrcController controller)
        {
            _controller = controller;
        }

        public void ProcessCommand(IrcClient client, string command)
        {
            var commandDetails = Parse(command);
        }

        private KeyValuePair<string, string[]> Parse(string rawCommand)
        {
            var commandName = string.Empty;
            var arguments = new List<string>();
            if (string.IsNullOrWhiteSpace(rawCommand))
                return new KeyValuePair<string, string[]>();

            var commandParts = rawCommand.Split(new[] {' '}, StringSplitOptions.RemoveEmptyEntries);
            
            // If the first part has a colon, than its an identifier and we can ignore it
            var partIndex = 0;
            if (commandParts[partIndex].StartsWith(":"))
                partIndex++;

            // Make sure we have any valid arguments left
            if (commandParts.Length >= partIndex)
                return new KeyValuePair<string, string[]>();

            // Extract the command name
            commandName = commandParts[partIndex];
            partIndex++;

            // Gather the rest of the arguments
            while (partIndex < commandParts.Length)
            {
                // If this argument starts with a colon, it means it's the last argument provided
                //   and it should be combined with all arguments afterwards
                if (commandParts[partIndex].StartsWith(":"))
                {
                    var builder = new StringBuilder(commandParts[partIndex].Substring(1));
                    partIndex++;

                    while (partIndex < commandParts.Length)
                    {
                        builder.Append(" ");
                        builder.Append(commandParts[partIndex]);
                        partIndex++;
                    }

                    arguments.Add(builder.ToString());
                }
                else
                {
                    arguments.Add(commandParts[partIndex]);
                }
            }

            return new KeyValuePair<string, string[]>(commandName, arguments.ToArray());
        }
    }
}
